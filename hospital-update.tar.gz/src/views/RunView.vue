<template>
  <div class="run-view">
    <!-- 准备阶段 -->
    <div v-if="runStore.phase === 'ready'" class="phase-content">
      <h2>测试准备</h2>
      <p>请确认测试参数：</p>
      <div class="test-info">
        <p><strong>测试名称：</strong>{{ testsStore.selectedTestName }}</p>
        <p><strong>患者：</strong>{{ runStore.currentPatient?.name }}</p>
        <p><strong>眼别：</strong>{{ testsStore.eye }}</p>
        <p><strong>模块数量：</strong>{{ testsStore.modules.length }}</p>
      </div>
      <el-button type="primary" size="large" @click="runStore.start()">开始测试</el-button>
    </div>

    <!-- 指导阶段 -->
    <div v-if="runStore.phase === 'guide'" class="phase-content">
      <h2>测试指导</h2>
      <div class="guide-text">
        <p>测试准备开始</p>
        <p>观察并判断光栅方向</p>
        <p>按空格键开始测试</p>
      </div>
      <el-button type="primary" size="large" @click="runStore.startCanvas()">开始测试</el-button>
    </div>

    <!-- 测试阶段 -->
    <div v-if="runStore.phase === 'canvas'" class="test-background" :style="{ backgroundColor: `rgb(${testsStore.basic?.bgRgb || '128,128,128'})` }">
      <div class="test-info-text">
        <h3>模块 {{ runStore.currentModuleIndex + 1 }} / {{ runStore.moduleOrder.length }}</h3>
        <p>当前对比度: {{ Number(runStore.currentContrast || 0).toFixed(1) }}% | 试验: {{ runStore.currentTrial }}</p>
        <p>Reversal: {{ runStore.reversalCount }} / {{ runStore.currentModule?.reversal }}</p>
        <p class="instruction-text">请判断光栅运动方向，按相应方向键：↑ 上  ↓ 下  ← 左  → 右</p>
        <p v-if="testsStore.basic?.showParams" class="params-text">
          空间频率: {{ runStore.currentModule?.spatial }} c/d | 
          时间频率: {{ runStore.currentModule?.temporal }} Hz | 
          对比度: {{ Number(runStore.currentContrast || 0).toFixed(1) }}%
        </p>
      </div>
      <div class="canvas-container">
        <RunCanvas />
      </div>
      </div>
      
    <!-- 模块间隔阶段 -->
    <div v-if="runStore.phase === 'moduleGap'" class="test-background" :style="{ backgroundColor: `rgb(${testsStore.basic?.bgRgb || '128,128,128'})` }">
      <div class="test-info-text">
        <h3>模块 {{ runStore.currentModuleIndex + 1 }} / {{ runStore.moduleOrder.length }} 已完成</h3>
        <p>准备下一个模块...</p>
      </div>
      <div class="canvas-container">
      <RunCanvas />
      </div>
    </div>

    <!-- 结束阶段 -->
    <div v-if="runStore.phase === 'end'" class="phase-content">
      <h2>测试结束</h2>
      <div class="results-summary">
        <h3>测试结果</h3>
        <div class="patient-info">
          <p><strong>姓名：</strong>{{ runStore.currentPatient?.name }}</p>
          <p><strong>性别：</strong>{{ runStore.currentPatient?.gender }}</p>
          <p><strong>生日：</strong>{{ runStore.currentPatient?.birthday }}</p>
          <p><strong>ID号：</strong>{{ runStore.currentPatient?.id }}</p>
          <p><strong>测试日期：</strong>{{ new Date().toLocaleDateString() }}</p>
          <p><strong>测试模式：</strong>{{ runStore.currentTest?.basic?.mode }}</p>
          <p><strong>测试眼别：</strong>{{ runStore.currentTest?.eye }}</p>
        </div>
        
        <div class="thresholds">
          <h4>各模块对比度阈值：</h4>
          <div v-for="(result, index) in runStore.moduleResults" :key="index" class="threshold-item">
            <p>模块 {{ index + 1 }}: {{ result.threshold.toFixed(2) }}% 
               (空间频率: {{ result.spatial }} c/d, 时间频率: {{ result.temporal }} Hz)</p>
            <ContrastChart
              v-if="result.trials && result.trials.length"
              :trials="result.trials"
              :title="`模块 ${index + 1} 对比度变化`"
            />
          </div>
        </div>
      </div>
      
      <div class="actions">
        <el-button type="primary" @click="exportResults">导出结果</el-button>
        <el-button @click="runStore.reset(); $router.push('/')">返回主界面</el-button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, onUnmounted } from 'vue'
import { useRunStore } from '../stores/run'
import { useTestsStore } from '../stores/tests'
import RunCanvas from '../widgets/RunCanvas.vue'
import ContrastChart from '../widgets/ContrastChart.vue'

const runStore = useRunStore()
const testsStore = useTestsStore()

const handleKeyPress = (e) => {
  if (runStore.phase === 'guide' && e.code === 'Space') {
    e.preventDefault()
    runStore.startCanvas()
  } else if (runStore.phase === 'canvas') {
    if (e.code === 'Escape') {
      e.preventDefault()
      // 测试过程中按ESC：保存当前进度并结束测试
      if (!runStore.currentSessionId && runStore.moduleResults.length > 0) {
        runStore.finishTest()
      } else {
      runStore.phase = 'end'
      }
    } else {
      const mode = runStore.currentTest?.basic?.mode || 'auto'
      
      // 手动模式：WASD 是医生控制光栅方向，方向键是患者判断
      if (mode === 'manual') {
        if (['KeyW', 'KeyS', 'KeyA', 'KeyD'].includes(e.code)) {
          e.preventDefault()
          runStore.handleDoctorControl(e.code)
    } else if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
      e.preventDefault()
      const keyMap = {
        'ArrowUp': 'up',
        'ArrowDown': 'down',
        'ArrowLeft': 'left',
        'ArrowRight': 'right'
      }
      runStore.handleKeyPress(keyMap[e.code])
        }
      } else {
        // 自动模式：只有方向键是患者判断
        if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.code)) {
          e.preventDefault()
          const keyMap = {
            'ArrowUp': 'up',
            'ArrowDown': 'down',
            'ArrowLeft': 'left',
            'ArrowRight': 'right'
          }
          runStore.handleKeyPress(keyMap[e.code])
        }
      }
    }
  } else if (runStore.phase === 'end' && e.code === 'Escape') {
    e.preventDefault()
    runStore.reset()
    // 结果页面按ESC：返回主界面
    window.location.href = '/'
  }
}

const exportResults = async () => {
  try {
    if (!runStore.currentSessionId) {
      alert('测试结果尚未保存，无法导出')
      return
    }
    const { exportTestResult } = await import('../utils/exporter')
    await exportTestResult(runStore.currentSessionId)
  } catch (e) {
    console.error('exportResults error', e)
    alert('导出失败：' + (e.message || '请检查后端服务'))
  }
}

onMounted(() => {
  document.addEventListener('keydown', handleKeyPress)
})

onUnmounted(() => {
  document.removeEventListener('keydown', handleKeyPress)
})
</script>

<style scoped>
.run-view {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

.phase-content {
  text-align: center;
  padding: 40px 20px;
}

.test-info {
  background: #f5f5f5;
  padding: 20px;
  border-radius: 8px;
  margin: 20px 0;
  text-align: left;
  max-width: 400px;
  margin-left: auto;
  margin-right: auto;
}

.guide-text {
  font-size: 18px;
  line-height: 1.6;
  margin: 30px 0;
}

.test-header {
  margin-bottom: 20px;
  padding: 15px;
  background: #f0f9ff;
  border-radius: 8px;
}

.test-header h3 {
  margin: 0 0 10px 0;
  color: #1890ff;
}

.test-header p {
  margin: 5px 0;
  font-size: 14px;
}

.test-background {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  overflow: hidden;
}

.test-info-text {
  width: 100%;
  text-align: center;
  color: #222;
  z-index: 10;
  background: rgba(240, 249, 255, 0.9);
  padding: 15px 20px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  flex-shrink: 0;
}

.test-info-text h3 {
  margin: 0 0 10px 0;
  color: #1890ff;
  font-size: 18px;
}

.test-info-text p {
  margin: 5px 0;
  font-size: 14px;
}

.instruction-text {
  font-weight: bold;
  margin-top: 10px !important;
}

.params-text {
  margin-top: 10px !important;
  font-size: 12px !important;
  color: #666;
}

.canvas-container {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100%;
  flex: 1;
  padding: 20px 0;
}

.instructions {
  margin-top: 20px;
}

.key-instructions {
  display: flex;
  justify-content: center;
  gap: 20px;
  margin-top: 15px;
}

.key {
  display: inline-block;
  padding: 8px 12px;
  background: #f0f0f0;
  border: 2px solid #ccc;
  border-radius: 4px;
  font-weight: bold;
  margin-right: 5px;
}

.results-summary {
  text-align: left;
  max-width: 600px;
  margin: 0 auto;
}

.patient-info {
  background: #f9f9f9;
  padding: 20px;
  border-radius: 8px;
  margin: 20px 0;
}

.thresholds {
  background: #f0f9ff;
  padding: 20px;
  border-radius: 8px;
  margin: 20px 0;
}

.threshold-item {
  padding: 8px 0;
  border-bottom: 1px solid #e0e0e0;
}

.threshold-item:last-child {
  border-bottom: none;
}

.actions {
  margin-top: 30px;
  display: flex;
  justify-content: center;
  gap: 20px;
}
</style>


