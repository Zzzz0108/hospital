<script setup>
</script>

<template>
  <router-view />
  
</template>

<style scoped>
  :global(body) {
    margin: 0;
    font-family: -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica,Arial,"Apple Color Emoji","Segoe UI Emoji";
    color: #111;
  }
  
</style>
